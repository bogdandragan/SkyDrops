

function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    return pattern.test(emailAddress);
}

/* =================================
 ===  LiveZilla                 ====
 =================================== */

function chatCloseButtonHide () {
    $('#lz_chat_close').hide();
}

$(document).on('click','.chatWith',function(eventObject){
    var customer_name=$("input[name='full_name']").val();
    var customer_email=$("input[name='email']").val();
    var customer_company=$("input[name='company']").val();
    var customer_country=$("input[name='country']").val();
    var form = $("#developmentForm").serializeArray();
    var valid = true;
    $.each($("#developmentForm input"), function(key, input){
        $("#"+input["id"]).removeClass("error-hightlight");
    });
    form.forEach(function(item,i,form) {
        if( (item["name"]=="email" || item["name"]=="full_name") && item["value"] === "" ) {
            $("#ctrl-"+item["name"]).addClass("error-hightlight");
            valid = false;
        } else {
            if (item["name"]=="email") {
                if(!isValidEmailAddress(item["value"])) {
                    $("#ctrl-"+item["name"]).addClass("error-hightlight");
                    valid = false;
                }
            }
        }
    });
    var buttonClose = '<div id="lz_chat_close" onclick="lz_chat_close();lz_chat_change_state(true,true);chatCloseButtonHide();" class="unselectable unmovable" style="width: 25px; height: 40px; top: 0; right: 0; position: absolute; cursor: pointer;"><div id="lz_chat_state_change" style="right: 10px; border-bottom-width: 0px; border-bottom-style: none; border-bottom-color: rgb(255, 255, 255);" class="unselectable"><span style="color: white; font-weight: bold;">&#10799;</span></div></div>';
    if(valid) {
        $('[name=form_111]')[0].value = customer_name;
        $('[name=form_112]')[0].value = customer_email;
        $('[name=form_113]')[0].value = customer_company;
        $('[name=form_0]')[0].value = customer_country;
        $('#lz_chat_overlay_text').click(function(){$('#lz_chat_close').show();});
        $('#lz_chat_minimize').click(function(){$('#lz_chat_close').hide();});
        $('#lz_chat_minimize').after(buttonClose);
        $('#lz_chat_overlay_text').width(200);
        $('#lz_chat_minimize').attr("style","right:25px; top: -2px;");
        $('[name=form_111]').change();
        $('[name=form_112]').change();
        $('[name=form_113]').change();
        $('[name=form_0]').change();
        lz_chat_change_state(true,false);
        $('#lz_overlay_chat').show();
        $('#lz_logo_firm img.lz_logo_firm').addClass("img-responsive");
        $('#lz_logo_firm img.lz_logo_firm').attr('src',"img/logo.png");
        $('#lz_chat_overlay_data_form_cancel_button')[0].click();
    }
});

$(document).on('click','.chatWith2',function(eventObject){
    var customer_name=$("input[name='full_name2']").val();
    var customer_email=$("input[name='email2']").val();
    var customer_company=$("input[name='company2']").val();
    var customer_country=$("input[name='country2']").val();
    var form = $("#developmentForm2").serializeArray();
    var valid = true;
    $.each($("#developmentForm2 input"), function(key, input){
        $("#"+input["id"]).removeClass("error-hightlight");
    });
    form.forEach(function(item,i,form) {
        if( (item["name"]=="email2" || item["name"]=="full_name2") && item["value"] === "" ) {
            $("#ctrl-"+item["name"]).addClass("error-hightlight");
            valid = false;
        } else {
            if (item["name"]=="email2") {
                if(!isValidEmailAddress(item["value"])) {
                    $("#ctrl-"+item["name"]).addClass("error-hightlight");
                    valid = false;
                }
            }
        }
    });
    var buttonClose = '<div id="lz_chat_close" onclick="lz_chat_close();lz_chat_change_state(true,true);chatCloseButtonHide();" class="unselectable unmovable" style="width: 25px; height: 40px; top: 0; right: 0; position: absolute; cursor: pointer;"><div id="lz_chat_state_change" style="right: 10px; border-bottom-width: 0px; border-bottom-style: none; border-bottom-color: rgb(255, 255, 255);" class="unselectable"><span style="color: white; font-weight: bold;">&#10799;</span></div></div>';
    if(valid) {
        $('[name=form_111]')[0].value = customer_name;
        $('[name=form_112]')[0].value = customer_email;
        $('[name=form_113]')[0].value = customer_company;
        $('[name=form_0]')[0].value = customer_country;
        $('#lz_chat_overlay_text').click(function(){$('#lz_chat_close').show();});
        $('#lz_chat_minimize').click(function(){$('#lz_chat_close').hide();});
        $('#lz_chat_minimize').after(buttonClose);
        $('#lz_chat_overlay_text').width(200);
        $('#lz_chat_minimize').attr("style","right:25px; top: -2px;");
        $('[name=form_111]').change();
        $('[name=form_112]').change();
        $('[name=form_113]').change();
        $('[name=form_0]').change();
        lz_chat_change_state(true,false);
        $('#lz_overlay_chat').show();
        $('#lz_logo_firm img.lz_logo_firm').addClass("img-responsive");
        $('#lz_logo_firm img.lz_logo_firm').attr('src',"img/logo.png");
        $('#lz_chat_overlay_data_form_cancel_button')[0].click();
    }
});

$(document).on('click','#liveChat',function(eventObject) {
    //$('#lz_overlay_chat').css('display','block');

    var buttonClose = '<div id="lz_chat_close" onclick="lz_chat_close();lz_chat_change_state(true,true);chatCloseButtonHide();" class="unselectable unmovable" style="width: 25px; height: 40px; top: 0; right: 0; position: absolute; cursor: pointer;"><div id="lz_chat_state_change" style="right: 10px; border-bottom-width: 0px; border-bottom-style: none; border-bottom-color: rgb(255, 255, 255);" class="unselectable"><span style="color: white; font-weight: bold;">&#10799;</span></div></div>';
    $('[name=form_111]')[0].value = "";
    $('[name=form_112]')[0].value = "";
    $('[name=form_113]')[0].value = "";
    $('[name=form_0]')[0].value = "";
    $('#lz_chat_overlay_text').click(function(){$('#lz_chat_close').show();});
    $('#lz_chat_minimize').click(function(){$('#lz_chat_close').hide();});
    $('#lz_chat_minimize').after(buttonClose);
    $('#lz_chat_overlay_text').width(200);
    $('#lz_chat_minimize').attr("style","right:25px; top: -2px;");
    $('[name=form_111]').change();
    $('[name=form_112]').change();
    $('[name=form_113]').change();
    $('[name=form_0]').change();
    lz_chat_change_state(true,false);
    $('#lz_overlay_chat').show();
    $('#lz_overlay_chat').css('display','block');
    $('#lz_logo_firm img.lz_logo_firm').addClass("img-responsive");
    $('#lz_logo_firm img.lz_logo_firm').attr('src',"img/logo.png");
});


function sendContactForm(form, url) {

    var jqxhr = $.ajax({
        url: url,
        type: "POST",
        data: form
    }).success(function() {
        $("#contactForm").hide();
        $(".thanks").show();
    }).error(function (xhr, ajaxOptions, thrownError) {
        $(".contactSuccess").hide();
        $(".contactDanger").show();
    });
}

function sendDevelopmentForm(form, url, number) {

    var jqxhr = $.ajax({
        url: url,
        type: "POST",
        data: form
    }).success(function() {
        if(number == 1){
            $("#developmentForm").hide();
            $(".thanksD").show();
        }
        else if(number == 2){
            $("#developmentForm2").hide();
            $(".thanksD2").show();
        }
    }).error(function (xhr, ajaxOptions, thrownError) {
        if(number == 1){
            $(".developmentSuccess").hide();
            $(".developmentDanger").show();
        }
        else if(number == 2){
            $(".developmentSuccess2").hide();
            $(".developmentDanger2").show();
        }
    });
}

$("#contactForm").submit(function(e) {
    e.preventDefault();

    var form = $("#contactForm").serializeArray();
    var valid = true;
    $.each($("#contactForm input"), function(key, input){
        $("#"+input["id"]).removeClass("error-hightlight");
    });
    form.forEach(function(item,i,form) {
        if( (item["name"]=="EmailC" || item["name"]=="Name" || item["name"]=="Subject" || item["name"]=="Message" ) && item["value"] === "" ) {
            $("#ctrl-"+item["name"]).addClass("error-hightlight");
            valid = false;
        } else {
            if (item["name"]=="EmailC") {
                if(!isValidEmailAddress(item["value"])) {
                    $("#ctrl-"+item["name"]).addClass("error-hightlight");
                    valid = false;
                }
            }
        }
    });

    if(valid){
        var form = $("#contactForm").serializeArray();
        var url = 'http://pingonline.komnicator.com/forms/skydev-contact-form';
        sendContactForm (form, url);
    }

});

$("#developmentForm").submit(function(e) {
    e.preventDefault();

    var form = $("#developmentForm").serializeArray();
    var valid = true;
    $.each($("#developmentForm input"), function(key, input){
        $("#"+input["id"]).removeClass("error-hightlight");
    });
    form.forEach(function(item,i,form) {
        if( (item["name"]=="email" || item["name"]=="full_name") && item["value"] === "" ) {
            $("#ctrl-"+item["name"]).addClass("error-hightlight");
            valid = false;
        } else {
            if (item["name"]=="email") {
                if(!isValidEmailAddress(item["value"])) {
                    $("#ctrl-"+item["name"]).addClass("error-hightlight");
                    valid = false;
                }
            }
        }
    });

    if(valid){
        var form = $("#developmentForm").serializeArray();
        var url = 'http://pingonline.komnicator.com/forms/skydev-free-development';
        sendDevelopmentForm (form, url, 1);
    }
});

$("#developmentForm2").submit(function(e) {
    e.preventDefault();

    var form = $("#developmentForm2").serializeArray();
    var valid = true;
    $.each($("#developmentForm2 input"), function(key, input){
        $("#"+input["id"]).removeClass("error-hightlight");
    });
    form.forEach(function(item,i,form) {
        if( (item["name"]=="email2" || item["name"]=="full_name2") && item["value"] === "" ) {
            $("#ctrl-"+item["name"]).addClass("error-hightlight");
            valid = false;
        } else {
            if (item["name"]=="email2") {
                if(!isValidEmailAddress(item["value"])) {
                    $("#ctrl-"+item["name"]).addClass("error-hightlight");
                    valid = false;
                }
            }
        }
    });

    if(valid){
        var form = $("#developmentForm2").serializeArray();
        var url = 'http://pingonline.komnicator.com/forms/skydev-free-development';
        sendDevelopmentForm (form, url, 2);
    }
});