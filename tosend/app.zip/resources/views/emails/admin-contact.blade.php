<style>
	body{
		color: #333;
		background: #ffffff;
		font-family: Arial, Tahoma;
		font-size: 14px;
	}
</style>

<body>
	<h1>SKyDrops</h1>
	<p>A person with the Email address <strong>{!! $email !!}</strong> filled up the contact from.</p>
</body>