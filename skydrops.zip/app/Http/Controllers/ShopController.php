<?php namespace App\Http\Controllers;

use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;

use App\User;
use Auth;
use Mail;
use DB;
use App\Drop as Drop;

class ShopController extends Controller {


    /**
     * Show the application dashboard to the user.
     *
     * @return Response
     */
    public function index()
    {
        if(Auth::check()){
            return view('shop');
        }
        else{
            return redirect("/");
        }
    }

    public function pay(){
        // Common setup for API credentials
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        $merchantAuthentication->setName("67c6dQHp");
        $merchantAuthentication->setTransactionKey("6UtNb664Egr89yG7");
        $refId = 'ref' . time();

        // Create the payment data for a credit card
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber("4111111111111111");
        $creditCard->setExpirationDate("1226");
        $creditCard->setCardCode("123");
        $paymentOne = new AnetAPI\PaymentType();
        $paymentOne->setCreditCard($creditCard);

        $order = new AnetAPI\OrderType();
        $order->setDescription("New Item");

        //create a transaction
        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType( "authCaptureTransaction");
        $transactionRequestType->setAmount(4.50);
        $transactionRequestType->setOrder($order);
        $transactionRequestType->setPayment($paymentOne);


        $request = new AnetAPI\CreateTransactionRequest();
        $request->setMerchantAuthentication($merchantAuthentication);
        $request->setRefId( $refId);
        $request->setTransactionRequest( $transactionRequestType);
        $controller = new AnetController\CreateTransactionController($request);
        $response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);

        if ($response != null)
        {
            $tresponse = $response->getTransactionResponse();

            if (($tresponse != null) && ($tresponse->getResponseCode() == 1) )
            {
                return $tresponse->getResponseCode();
            }
            else
            {
                return  "Charge Credit Card ERROR :  Invalid response\n";
            }

        }
        else
        {
            return  "Charge Credit card Null response returned";
        }

    }


}
