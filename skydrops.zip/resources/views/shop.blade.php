@extends('master')

@section('title')
    Buy coins | SkyDrops Beta
@endsection

@section('createFEButton')
    <a class="button" href="/upload">Create Drop</a>
@endsection

@section('scripts')
    {!! HTML::script('/js/jquery.min.js') !!}
    {!! HTML::script('/js/bootstrap.min.js') !!}
    {!! HTML::script('/js/jquery-ui.min.js') !!}
    {!! HTML::script('/js/bootstrap-datepicker.js') !!}
    {!! HTML::script('/js/autosize.js') !!}
    {!! HTML::script('/js/dropzone.js') !!}
    {!! HTML::script('/js/selectize.js') !!}
    {!! HTML::script('/js/sweetalert.min.js') !!}
    {!! HTML::script('/js/chart.min.js') !!}
    {!! HTML::script('/js/jquery.overlay.min.js') !!}
    {!! HTML::script('/js/jquery.textcomplete.min.js') !!}
    {!! HTML::script('/js/skydrops.js') !!}
@endsection

@section('style')
    body{
        background: url({{ asset('/img/banknote-1396352_1920.jpg') }}) repeat-y center center;
        background-position: 10% 20%;
    }

    .coin10{
    height: 200px;
    }

    .coin30{
    height: 200px;
    }

    .coin100{
    height: 200px;
    }

    .coinPackage{
        border: 4px solid #414896;
        border-radius: 15px;
        margin: 0 auto;
        padding-bottom: 25px;
        margin-bottom: 20px;
        background-color: #ececf4;
    }

    .coinPackage h1{
        color: #000 !important;
        font-size: 40px !important;
        font-weight: bold !important;
        margin-left: 20px;
    }

    .addShadow{
        box-shadow: 0px 0px 10px 1px rgba(65,72,150,1);
    }

    .price{
        display: inline-block;
    }

    input[type='radio']{
        display: block !important;
        margin: 5px;
    }
@endsection

@section('content')

    <div class="container noSubHeader wrap">
        <!-- Content start -->
        <div class="box" style="padding: 20px;">
            <div class="row">
                <h1 style="font-weight: normal; margin-left: 20px;">Select coin package</h1>
                <div class="col-md-4 section-abcde">
                    <div class="coinPackage">
                        <input type="radio" name="selectCoins" value="10" id="10Coins" checked="false">
                        <img class="coin10" src="{{ asset("/img/coin_10.png")}}">
                        <h1 class="price">5$</h1>
                        <!--<a class="btn btn-primary registerButton buyBtn" href="#" style="margin-top: 20px;">Buy Coin Package</a>-->
                    </div>
                </div>
                <div class="col-md-4 section-abcde">
                    <div class="coinPackage">
                        <input type="radio" name="selectCoins" value="30" id="30Coins">
                        <img class="coin30" src="{{ asset("/img/coin_30.png")}}">
                        <h1 class="price">12$</h1>
                    </div>
                </div>
                <div class="col-md-4 section-abcde">
                    <div class="coinPackage">
                        <input type="radio" name="selectCoins" value="100" id="100Coins">
                        <img class="coin100" src="{{ asset("/img/coin_100.png")}}">
                        <h1 class="price">30$</h1>
                    </div>
                </div>
            </div>

            <div class="panel panel-default credit-card-box" style="display: none;">
                <div class="panel-heading display-table" >
                    <div class="row">
                        <h3 class="panel-title" style="float: left; margin: 10px 0px 0px 20px;">Payment Details</h3>
                        <div style="float: right">
                            <img class="img-responsive pull-right" src="http://i76.imgup.net/accepted_c22e0.png">
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <form role="form" id="cardForm">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label for="cardNumber">CARD NUMBER</label>
                                    <div class="input-group">
                                        <input type="tel" class="form-control" name="cardNumber" placeholder="Valid Card Number" autocomplete="cc-number" required autofocus/>
                                        <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-7 col-md-7">
                                <div class="form-group">
                                    <label for="cardExpiry"><span class="hidden-xs">EXPIRATION</span><span class="visible-xs-inline">EXP</span> DATE</label>
                                    <input type="tel" class="form-control" name="cardExpiry" placeholder="MM / YY" autocomplete="cc-exp" required/>
                                </div>
                            </div>
                            <div class="col-xs-5 col-md-5 pull-right">
                                <div class="form-group">
                                    <label for="cardCVC">CV CODE</label>
                                    <input type="tel" class="form-control" name="cardCVC" placeholder="CVC" autocomplete="cc-csc" required/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                    <label for="couponCode">NAME</label>
                                    <input type="text" class="form-control" name="couponCode" />
                                </div>
                            </div>
                        </div>
                        {!! Form::token() !!}
                        <div class="row">
                            <div class="col-xs-12">
                                <button class="btn btn-success btn-lg btn-block" id="submitBtn" type="submit">Submit</button>
                            </div>
                        </div>
                        <div class="row" style="display:none;">
                            <div class="col-xs-12">
                                <p class="payment-errors"></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Content end -->
    </div>

    @if(Auth::check())

    @endif

    <script>
        $("input[name='selectCoins']").prop('checked', false);

        $("input[name='selectCoins']").change(function(e){
            if($(this).val() == '10') {
                $(this).parent().addClass('addShadow');
                $("#30Coins").parent().removeClass('addShadow');
                $("#100Coins").parent().removeClass('addShadow');
                $(".credit-card-box").css('display','block');
            } else if($(this).val() == '30') {
                $(this).parent().addClass('addShadow');
                $("#10Coins").parent().removeClass('addShadow');
                $("#100Coins").parent().removeClass('addShadow');
                $(".credit-card-box").css('display','block');
            } else if($(this).val() == '100') {
                $(this).parent().addClass('addShadow');
                $("#10Coins").parent().removeClass('addShadow');
                $("#30Coins").parent().removeClass('addShadow');
                $(".credit-card-box").css('display','block');
            }

        });

        $("#cardForm").submit(function(e) {
            e.preventDefault();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('input[name="_token"]').val()
                }
            });

            $.ajax({
                type:	'POST',
                url:	'/shop/pay',
                data:	$("#cardForm").serialize(),
                success: function(data){

                },
                error: function(data){

                }
            });

        });
    </script>
@endsection
